/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : datasource1

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-05-04 20:33:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `menu_type` int(10) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES ('1', '资产组合', '资产组合', '0', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('2', '工作流', '工作流', '0', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('3', '配置', '配置', '0', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('4', '楼宇管理', '楼宇管理', '1', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('5', '招商管理', '招商管理', '1', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('6', '财务管理', '财务管理', '1', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('7', '查看楼宇', '查看楼宇', '4', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('8', '新增楼宇', '新增楼宇', '4', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('9', '修改楼宇', '修改楼宇', '4', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('10', '房源管理', '房源管理', '5', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('11', '合同管理', '合同管理', '5', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('12', '租户管理', '租户管理', '5', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('13', '查看房源', '查看房源', '10', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('14', '新增房源', '新增房源', '10', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('15', '修改房源', '修改房源', '10', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('16', '查看合同', '查看合同', '11', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('17', '新增合同', '新增合同', '11', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('18', '修改合同', '修改合同', '11', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('19', '查看租户', '查看租户', '12', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('20', '新增租户', '新增租户', '12', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('21', '修改租户', '修改租户', '12', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('22', '账单', '账单', '6', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('23', '收支', '收支', '6', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('24', '查看账单', '查看账单', '22', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('25', '新增账单', '新增账单', '22', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('26', '修改账单', '修改账单', '22', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('27', '查看收支', '查看收支', '23', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('28', '新增收支', '新增收支', '24', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('29', '修改收支', '修改收支', '24', null, '1', '1');
INSERT INTO `sys_menu` VALUES ('30', '修改收支', '修改收支', '24', null, '1', '1');
