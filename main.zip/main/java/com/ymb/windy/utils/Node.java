package com.ymb.windy.utils;

import java.util.ArrayList;
import java.util.List;

public class Node {

    /**
     * 子节点id
     */
    private Integer id;

    /**
     * 节点名称
     */
    private String name;

    /**
     * 父节点id
     */
    private Integer parentId;

    /**
     *是否选择
     */
    private boolean checked = false;

    /**
     *子节点
     */
    private List<Node> children = new ArrayList<Node>();

    public Node() {

    }

    public Node(Integer id, String name, Integer parentId) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
    }

    public Node(Integer id, String name, Integer parentId, List<Node> children) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
        this.children = children;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public List<Node> getChildren() {
        return children;
    }

    public void setChildren(List<Node> children) {
        this.children = children;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    @Override
    public String toString() {
        return "Node{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", parentId=" + parentId +
                ", checked=" + checked +
                ", children=" + children +
                '}';
    }
}
