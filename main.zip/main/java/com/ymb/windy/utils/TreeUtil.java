package com.ymb.windy.utils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TreeUtil {

    private static ThreadLocal<List<Node>> nodeList = new ThreadLocal<>();

    private static List<Node> cList = new ArrayList<>();

    // 入口方法
    public static List<Node> getTree(List<Node> nodeList) {
        List<Node> list = new ArrayList<>();
        // 遍历节点列表
        for (Node node : nodeList) {
            if (node.getParentId().equals(0)) {
                // parentId为0（根节点）作为入口
                node.setChildren( getChildrenNode(node.getId(), nodeList));
                list.add(node);
            }
        }
        return list;
    }

    // 获取子节点的递归方法
    private static List<Node> getChildrenNode(Integer id, List<Node> nodeList) {
        List<Node> list = new ArrayList<Node>();
        for (Node node : nodeList) {
            if (node.getParentId().equals(id)) {
                // 递归获取子节点
                node.setChildren(getChildrenNode(node.getId(), nodeList));
                list.add(node);
            }
        }
        return list;
    }

    /**
     * TODO: 递归查找子分类
     */
    public static Node Recursion(List<Node> root) {
        if (root == null) {
            return null;
        } else {
            Node nodeResult = null;
            for (Node node : root) {
                cList.add(node);
                nodeList.set(cList);
                //如果有子分类继续查找
                if (hasChild(node)) {
                    nodeResult = Recursion(node.getChildren());
                }
            }
            return nodeResult;
        }
    }

    /**
     * TODO: 判断树是否有子节点
     */
    private static boolean hasChild(Node root) {
        boolean has = false;
        if (root != null && root.getChildren() != null && !root.getChildren().isEmpty()) {
            has = true;
        }
        return has;
    }

    public static ThreadLocal<List<Node>> getNodeList() {
        return nodeList;
    }

    public static void setNodeList(ThreadLocal<List<Node>> nodeList) {
        TreeUtil.nodeList = nodeList;
    }

    public static List<Node> getcList() {

        return cList;
    }

    public static void setcList(List<Node> cList) {
        TreeUtil.cList = cList;
    }
}
