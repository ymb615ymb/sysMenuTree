package com.ymb.windy.datasource1.mapper;

import com.ymb.windy.datasource1.entity.SysMenu;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SysMenuMapping {

	public void saveSysMenu(SysMenu sysMenu);

    public List<SysMenu> queryAllSysMenu();
}
