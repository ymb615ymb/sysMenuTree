package com.ymb.windy.datasource1.service;

import com.ymb.windy.datasource1.entity.SysMenu;

import java.util.List;

public interface SysMenuService {

	public void saveSysMenu(SysMenu sysMenu);

    public List<SysMenu> queryAllSysMenu();
}
