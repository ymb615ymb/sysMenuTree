package com.ymb.windy.datasource1.service.impl;

import com.ymb.windy.datasource1.entity.SysMenu;
import com.ymb.windy.datasource1.mapper.SysMenuMapping;
import com.ymb.windy.datasource1.service.SysMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Service
public class SysMenuServiceImpl implements SysMenuService {

	@Autowired
	private SysMenuMapping sysMenuMapping;

	@Transactional
	@Override
	public void saveSysMenu(SysMenu sysMenu) {

		sysMenuMapping.saveSysMenu(sysMenu);
	}

	@Transactional
	@Override
	public List<SysMenu> queryAllSysMenu() {

		return sysMenuMapping.queryAllSysMenu();
	}
}
