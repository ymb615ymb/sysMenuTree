package com.ymb.windy.datasource1.controller;

import com.alibaba.druid.support.json.JSONUtils;
import com.ymb.windy.datasource1.entity.SysMenu;
import com.ymb.windy.datasource1.service.SysMenuService;
import com.ymb.windy.utils.Node;
import com.ymb.windy.utils.TreeUtil;
import com.ymb.windy.vo.OrgOrganizationVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * 多数据源事务
 *
 */
@RestController
public class SysMenuController {

	@Autowired
	private SysMenuService sysMenuService;

	@RequestMapping("/sysMenu/saveSysMenu")
	public String saveUser() {
		SysMenu sysMenu = new SysMenu();
		sysMenu.setTitle("111");
		sysMenu.setPid(12);
		sysMenu.setStatus(1);
		sysMenu.setMenuType(1);
		sysMenu.setDesc("111");
		return "success";
	}

	@RequestMapping("/sysMenu/getAllSysMenu")
	public List<SysMenu> getAllSysMenu(){

		return sysMenuService.queryAllSysMenu();
	}

	@RequestMapping("/sysMenu/getAllOrgOrganization")
	public OrgOrganizationVo getAllOrgOrganization(){
		OrgOrganizationVo orgOrganizationVo = new OrgOrganizationVo();
		orgOrganizationVo.setId(1);
		orgOrganizationVo.setDesc("组织");
		orgOrganizationVo.setOrgName("组织");
		orgOrganizationVo.setOrgCode("zuzhi");

		List<SysMenu> list = sysMenuService.queryAllSysMenu();

		List<Node> nodeList = new ArrayList<>();

		for (SysMenu sysMenu :list){
			nodeList.add(new Node(sysMenu.getId(), sysMenu.getTitle(), sysMenu.getPid()));
		}
		List<Node> nodeTree = TreeUtil.getTree(nodeList);

		orgOrganizationVo.setSysMenuList(nodeTree);

		// 解析tree
		TreeUtil.Recursion(orgOrganizationVo.getSysMenuList());
		List<Node> nodes = TreeUtil.getNodeList().get();
		System.out.println(nodes.toString());

		return orgOrganizationVo;
	}

}
