package com.ymb.windy.vo;

import com.ymb.windy.datasource1.entity.SysMenu;
import com.ymb.windy.utils.Node;

import java.util.List;

public class OrgOrganizationVo {
    private Integer id;

    private String orgCode;

    private String orgName;

    private String desc;

    private List<Node> sysMenuList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public List<Node> getSysMenuList() {
        return sysMenuList;
    }

    public void setSysMenuList(List<Node> sysMenuList) {
        this.sysMenuList = sysMenuList;
    }
}
